# burp-frame/scripts/modules/__init__.py

# This file can be empty. Its presence makes 'modules' a Python package.
